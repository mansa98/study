package com.mbc.leteatgo.repository;

import org.springframework.data.repository.CrudRepository;
import com.mbc.leteatgo.domain.IngrSubVO;

public interface IngrSubRepository extends CrudRepository<IngrSubVO, Integer> {

}
