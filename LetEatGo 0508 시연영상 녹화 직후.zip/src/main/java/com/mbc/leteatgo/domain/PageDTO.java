package com.mbc.leteatgo.domain;

public class PageDTO {

}
