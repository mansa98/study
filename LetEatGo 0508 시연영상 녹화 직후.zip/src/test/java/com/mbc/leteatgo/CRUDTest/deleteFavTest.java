//package com.mbc.leteatgo.CRUDTest;
//
//import static org.junit.jupiter.api.Assertions.*;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//
//import com.mbc.leteatgo.domain.FavVO;
//import com.mbc.leteatgo.repository.FavRepository;
//import com.mbc.leteatgo.service.FavService;
//
//@SpringBootTest
//class deleteFavTest {
//	
//	@Autowired
//	FavService favService;
//	
//	@Autowired
//	FavRepository fr;
//
//	@Test
////	void test() {
////		
////		int recipeNum = 982;
////		
////		//favService.deleteFav(3);
////		
////		//fr.deleteByRecipeNum(recipeNum);
////		
////		FavVO favVO = null;
////		
////		//favVO = fr.findByRecipeNum(recipeNum);
////		
////		System.out.println(favVO.toString());
//		
//	}
//
//}
