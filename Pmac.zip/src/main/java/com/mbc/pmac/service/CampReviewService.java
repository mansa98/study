package com.mbc.pmac.service;

import org.springframework.stereotype.Service;

@Service
public class CampReviewService {

}
